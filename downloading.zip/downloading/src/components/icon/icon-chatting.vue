<template>
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <!-- Frame berbentuk persegi dengan ujung melengkung -->
        <path
            d="M6 3H18C19.6569 3 21 4.34315 21 6V18C21 19.6569 19.6569 21 18 21H6C4.34315 21 3 19.6569 3 18V6C3 4.34315 4.34315 3 6 3Z"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <!-- Bintang besar -->
        <path
            d="M12 8L13 10L15 11L13 12L12 14L11 12L9 11L11 10L12 8Z"
            fill="currentColor"
        />
        <!-- Bintang kecil kanan atas -->
        <path
            d="M17 5L17.5 6L18.5 6.5L17.5 7L17 8L16.5 7L15.5 6.5L16.5 6L17 5Z"
            fill="currentColor"
        />
        <!-- Bintang kecil kiri bawah -->
        <path
            d="M7 15L7.5 16L8.5 16.5L7.5 17L7 18L6.5 17L5.5 16.5L6.5 16L7 15Z"
            fill="currentColor" 
        />
    </svg>
</template>

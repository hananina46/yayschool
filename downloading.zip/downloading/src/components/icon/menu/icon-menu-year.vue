<template>
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <!-- Topi toga -->
        <path
            d="M12 4L4 8L12 12L20 8L12 4Z"
            fill="currentColor"
        />
        <path
            opacity="0.5"
            d="M12 12V16"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            opacity="0.5"
            d="M8 10L8 14L16 14L16 10"
            fill="currentColor"
        />
        <!-- Tali topi -->
        <path
            d="M16 10C16 10 17 11 17.5 11.5"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
        />
    </svg>
</template>

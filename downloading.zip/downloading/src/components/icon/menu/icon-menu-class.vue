<template>
    <svg
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
    >
        <!-- Lingkaran luar -->
        <circle
            opacity="0.5"
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            stroke-width="1.5"
        />
        <!-- Simbol buku terbuka -->
        <path
            d="M9 9.5H7C6.44772 9.5 6 9.94772 6 10.5V14.5C6 15.0523 6.44772 15.5 7 15.5H9"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M15 9.5H17C17.5523 9.5 18 9.94772 18 10.5V14.5C18 15.0523 17.5523 15.5 17 15.5H15"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M9 9.5C9 10.5 9.5 14.5 12 14.5C14.5 14.5 15 10.5 15 9.5"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
    </svg>
</template>

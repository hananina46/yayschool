<template>
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <!-- Kepala Guardian (Orang Tua/Wali) -->
        <circle opacity="0.5" cx="8" cy="6" r="3" fill="currentColor" />
        <!-- Badan Guardian -->
        <ellipse opacity="0.5" cx="8" cy="17" rx="6" ry="3" fill="currentColor" />
        <!-- Kepala Student -->
        <circle cx="16" cy="8" r="2.5" fill="currentColor" />
        <!-- Badan Student -->
        <ellipse cx="16" cy="18" rx="5" ry="2.5" fill="currentColor" />
    </svg>
</template>

<template>
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <!-- Buku terbuka -->
        <path
            opacity="0.5"
            d="M4 6C4 5.44772 4.44772 5 5 5H10C10.5523 5 11 5.44772 11 6V18C11 18.5523 10.5523 19 10 19H5C4.44772 19 4 18.5523 4 18V6Z"
            fill="currentColor"
        />
        <path
            d="M13 6C13 5.44772 13.4477 5 14 5H19C19.5523 5 20 5.44772 20 6V18C20 18.5523 19.5523 19 19 19H14C13.4477 19 13 18.5523 13 18V6Z"
            fill="currentColor"
        />
        <!-- Garis isi buku -->
        <path
            d="M7 8H9"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
        />
        <path
            d="M15 8H17"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
        />
    </svg>
</template>

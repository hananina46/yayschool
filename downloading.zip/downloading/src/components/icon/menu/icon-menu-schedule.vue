<template>
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <!-- Kalender -->
        <rect
            x="3"
            y="5"
            width="18"
            height="14"
            rx="2"
            fill="currentColor"
            opacity="0.5"
        />
        <!-- Garis atas kalender -->
        <path
            d="M3 9H21"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
        />
        <!-- Lingkaran jam -->
        <circle cx="12" cy="14" r="3" fill="currentColor" />
        <!-- Jarum jam -->
        <path
            d="M12 13V15"
            stroke="white"
            stroke-width="1.5"
            stroke-linecap="round"
        />
        <path
            d="M12 14H13.5"
            stroke="white"
            stroke-width="1.5"
            stroke-linecap="round"
        />
    </svg>
</template>
